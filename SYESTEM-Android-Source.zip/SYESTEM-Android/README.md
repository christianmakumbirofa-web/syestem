# SYESTEM AI — Android starter

This is a mobile-first installable web app (PWA) with:
- AI chat through a private server endpoint
- Speech input where the browser supports Web Speech recognition
- Spoken answers using browser text-to-speech
- A local task list saved on the phone
- Install-to-home-screen support and basic offline caching

## Important
This package is source code, not a signed Android APK. Deploy it to HTTPS, then open it in Chrome on Android and choose **Install app** / **Add to Home screen**.

The AI feature will only work after you configure an OpenAI API key on the server. API use may incur charges. Ask a parent or guardian to help with account setup and any billing. Never put the secret key in `public/`, in the Android app, or in a public GitHub repository.

## Deploy (simple route)
1. Create a private GitHub repository and upload these project files.
2. Create a web service on Render and connect the repository.
3. Render should detect `render.yaml`; use `npm install` for build and `npm start` for start.
4. In the Render service's Environment settings, add:
   - `OPENAI_API_KEY` = your secret API key
   - `OPENAI_MODEL` = a model available to your API project (default in this starter: `gpt-6-luna`)
5. Deploy. Open the service's HTTPS address on your Android phone in Chrome.
6. Chrome menu (⋮) → **Install app** or **Add to Home screen**.

## Run locally on a computer
Requires Node.js 18+.
1. Copy `.env.example` to `.env` and add your key.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Current limits
- This is not a native Android app and does not yet control phone settings.
- It does not have an always-on wake word; tap Speak to start voice recognition.
- The G28/JYouPro watch is not directly integrated yet. We should first verify what notifications and Bluetooth features your exact watch supports.
- The backend currently sends each message as a single request; it does not keep chat history on the server.

## API security
The server reads `OPENAI_API_KEY` from an environment variable and sends requests to the OpenAI Responses API. Do not expose the key to client-side code.
